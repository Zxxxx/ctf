#coding=utf-8

'''
WhatFormat.py
'''

import os
import sys
import binascii

#dict = r'C:\MyTools\whatFormat.dic'
dict = 'whatFormat.dic'

def usage():
    data = '''
[+] This script help you to find outthe real format of the file or hide data from the file!
[+] the result file save at 'output' dir, go and search it!
[+] http://hi.baidu.com/l34rn
[+] cnh4ckff [at] gmail.com

[+] usage: %s <target file>
    '''% sys.argv[0].split('\\')[-1]
    print data
    
def loadDict(dict):
    dictList = []
    with open(dict,'r') as lines:
        for line in lines:
            if line.strip() != '':
                if not line.startswith('#'):
                    ext,des,hexDump = line.split('::')
                    dictList.append([ext,des,hexDump])
    return dictList
    
def loadFile(file):
    size = os.path.getsize(file)
    print '''
[+] File:               %s
[+] Size:               %s [Kb]
    '''%(file,str(size/1024))
    with open(file,'rb') as f:
        data = f.read()
        hexData = binascii.hexlify(data)
    return hexData
    
def checkFormat(hexData,dictList):
    resList = []
    for dict in dictList:
        starup = 0
        hexDump = ''
        for hexDumpTmp in dict[2].strip():
            hexDumpTmp = hexDumpTmp.strip()
            if hexDumpTmp != '':
                hexDump += hexDumpTmp.lower()
        while True:
            code = hexData.find(hexDump,starup)
            if code != -1:
                starup = code+1
                resList.append([dict[0].strip(),dict[1].strip(),code])
            else:
                break
    return resList
    
def output(resList,hexData):
    i = 0
    for res in resList:
        i += 1
        num = str(i)
        ext = res[0]
        des = res[1]
        startup = int(res[2])
        fileName = num+'.'+ext
        data = binascii.unhexlify(hexData[startup:])
        saveFile(fileName,data)
        print '''
[+] Number:             %s
[+] Extension:          %s
[+] Description:        %s
[+] Startup:            %s
[+] Saveas:             %s
        '''%(num ,ext,des,startup,fileName)
        
def saveFile(fileName,data):
    if not os.path.exists('output'):
        os.mkdir('output')
    with open('output/'+fileName,'wb') as f:
        f.write(data)

def main():
    if len(sys.argv) < 2:
        usage()
        exit()
    file = sys.argv[1]
    hexData = loadFile(file)
    dictList = loadDict(dict)
    resList = checkFormat(hexData, dictList)
    output(resList,hexData)
    
    
if __name__ == '__main__':
    try:
        main()    
    except Exception,e:
        print '[+] ',e
    